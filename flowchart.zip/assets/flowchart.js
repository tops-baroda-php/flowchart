
     $( function() {
  $( "#2" ).draggable({ helper: "clone" });

  $('#2').draggable({helper: "clone"});

$('#2').bind('dragstop', function(event, ui) {
    $(this).after($(ui.helper).clone().draggable());
});
    
   } );


