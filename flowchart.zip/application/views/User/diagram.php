<!-- <script type="text/javascript" src="js/jquery-1.9.1.min.js"></script> -->

<script
  src="https://code.jquery.com/jquery-3.3.1.min.js"
  integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8="
  crossorigin="anonymous"></script>
<!-- <script
  src="https://code.jquery.com/ui/1.12.1/jquery-ui.min.js"
  integrity="sha256-VazP97ZCwtekAsvgPBSUwPFKdrwD3unUfSGVYrahUqU="
  crossorigin="anonymous"></script> -->
  <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.4/jquery.min.js"></script>
<script src="http://ajax.googleapis.com/ajax/libs/jqueryui/1.8/jquery-ui.min.js"></script>

  <!-- <script async src="//jsfiddle.net/Twisty/18erqbqv/23/embed/"></script> -->
<div id="parts">
  <div class="draggable">
  </div>
</div>

<div id="drawzone">
  <div class="grid" data-size="10">
  </div>
  <div class="droppable">
  </div>
</div>
<style type="text/css">
  body {
  padding: 0;
}

#parts {
  border: 2px solid #000;
  padding: 7px;
  height: 44px;
  margin-bottom: 3px;
  width: 200px;
}

#parts .color-button {
  float: left;
  text-decoration: none;
}

.draggable,
.dropped {
  background-color: rgba(128, 255, 128, 0.85);
  border: 1px solid #000;
  height: 38px;
  text-align: center;
  width: 38px;
}

.dropped {
  font-family: Arial, san-seriff;
  display: table;
}

.dropped .label {
  text-align: center;
}

.draggable {
  background-color: rgba(128, 255, 128, 0.65);
}

.selected {
  border-color: #f30;
}

.ui-resizable-handle {
  width: 4px;
  height: 4px;
  background-color: #fff;
  border: 1px solid #000;
}

.ui-resizable-ne {
  top: -3px;
  right: -3px
}

.ui-resizable-nw {
  left: -3px;
  top: -3px
}

.ui-resizable-se {
  bottom: -3px;
  right: -3px
}

.ui-resizable-sw {
  bottom: -3px;
  left: -3px
}

#drawzone {
  display: block;
  max-height: 200px;
  position: relative;
  max-width: 200px;
}

.grid {
  border: 1px solid #ccc;
  border-width: 1px 0 0 1px;
  position: absolute;
  top: 0;
  left: 0;
}

.grid div {
  border: 1px solid #ccc;
  border-width: 0 1px 1px 0;
  float: left;
}

.droppable {
  display: block;
  border: 1px solid #222;
  position: absolute;
  top: 0;
  left: 0;
  z-index: 1000;
}

</style>
<script type="text/javascript">
  var myGridContent = [];
var dropSnap = true;

function createGrid(t, w, h, s, g) {
  /*
  t - Target Element: OBJ
  w - Grid Width: PX
  h - Grid Height: PX
  s - Grid Size: PX
  g - Gutter Size: INT
  */
  g = (g !== null ? g : false);
  var ratio = {
    w: Math.floor(w / s),
    h: Math.floor(h / s)
  };
  console.log(ratio);
  var parent = $(t);
  if (!parent.hasClass("grid")) {
    parent.addClass("grid");
  }
  if (g) {
    g = (parseInt(g) === g ? g : s);
    parent.css({
      width: w + "px",
      height: h + "px",
      top: g + "px",
      left: g + "px"
    });
    $(".droppable").css({
      width: w + "px",
      height: h + "px",
      top: g + "px",
      left: g + "px"
    })
  }
  var gridCells = [];

  for (var i = 0; i < ratio.h; i++) {
    for (var p = 0; p < ratio.w; p++) {
      gridCells.push('<div style="width:', (s - 1), 'px;height:', (s - 1), 'px;" data-row="' + i + '" data-col="' + p + '"></div>');
    }
  }
  parent.html(gridCells.join(""));
}

createGrid(".grid", 400, 400, 10, 20);

$(function() {
  $(".draggable").draggable({
    helper: 'clone',
    cursor: "move",
    containment: ".droppable",
    zIndex: 1001,
    appendTo: ".droppable"
  });
  $(".droppable").droppable({
      accept: ".draggable",
      drop: function(e, ui) {
        var pos = ui.position;
        var $obj = ui.helper.clone();
        var c = $(".dropped").length;
        $obj.removeClass("draggable");
        $obj.addClass("dropped");
        if (dropSnap) {
          pos.top = Math.round(pos.top / 10) * 10;
          pos.left = Math.round(pos.left / 10) * 10;
        }
        $obj.css({
          position: 'absolute',
          top: pos.top + "px",
          left: pos.left + "px"
        });
        c++;
        $obj.html("<span class='label' style='margin: auto 0'>" + c + "</span>");
        $obj.click(function(e) {
            $(".selected").removeClass("selected");
            var self = $(this);
            self.addClass("selected");
            self.draggable({
              containment: 'parent',
              grid: [$(".grid").data("size"), $(".grid").data("size")]
            });
            self.resizable({
                handles: "ne, nw, se, sw",
                grid: $(".grid").data("size"),
                ghost: true,
                stop: function(e, ui) {
                  console.log("Resize Stopped on ID: " + $(this).data("obj").id);
                  $(this).data("obj").width = ui.size.width;
                  $(this).data("obj").height = ui.size.height;
                }
            }); console.log(self.data());
        });$obj.data("obj", {
        id: c,
        label: $obj.text(),
        top: pos.top,
        left: pos.left,
        width: $obj.width(),
        height: $obj.height(),
        layer: $obj.zIndex() - 1000
      });$obj.appendTo(".droppable");myGridContent.push({
        id: c,
        l: pos.left,
        t: pos.top,
        w: $obj.width(),
        h: $obj.height(),
        bg: $obj.css("background-color")
      });
    }
  }); $(".droppable").click(function(e) {
  if (!$(e.target).hasClass("dropped")) {
    $(".selected")
      .removeClass("selected")
      .draggable("destroy")
      .resizable("destroy");
  }
}); $(document).keyup(function(e) {
  if ($(".selected").length) {
    var $obj = $(".selected");
    var bump = $(".grid").data("size");
    console.log(e.keyCode);
    switch (e.keyCode) {
      case 38:
        // Up
        if ($obj.position().top >= bump) {
          $obj.css("top", $obj.position().top - bump);
        }
        break;
      case 40:
        // Down
        if ($obj.position().top + $obj.height() <= $(".droppable").height() - bump) {
          $obj.css("top", $obj.position().top + bump);
        }
        break;
      case 37:
        // left
        if ($obj.position().left >= bump) {
          $obj.css("left", $obj.position().left - bump);
        }
        break;
      case 39:
        // Right
        if ($obj.position().left + $obj.width() <= $(".droppable").width() - bump) {
          $obj.css("left", $obj.position().left + bump);
        }
        break;
      case 46:
        // Del
        $obj.remove();
    }
  }
});
});

</script>