<!DOCTYPE html>
<html>
<head>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

    <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
  <link rel="stylesheet" href="/resources/demos/style.css">
  <link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>assets/flowchart.js">

  <style>
  #draggable { width: 150px; height: 150px; padding: 0.5em; }
  </style>
  <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>

  <script type="text/javascript">


     $( function() {
  $( "#f2" ).draggable({ helper: "clone" });

  $('#f2').draggable({helper: "clone"});

$('#f2').bind('dragstop', function(event, ui) {
    $(this).after($(ui.helper).clone().draggable());
});
    
   } );

     $("#f2").click(function(e) {
    $(this).closest("#f2").remove();
    e.preventDefault();
});






  </script>

    <script type="text/javascript">


     $( function() {
  $( "#7" ).draggable({ helper: "clone" });

  $('#7').draggable({helper: "clone"});

$('#7').bind('dragstop', function(event, ui) {
    $(this).after($(ui.helper).clone().draggable());
});

$(document).on("click", "#7", function() {
    $(this).closest(".box").remove();
});
    
   } );




  </script>

  <script>
     $( function() {
  //$( "#draggable" ).draggable({ helper: "clone" });

  $('#draggable').draggable({helper: "clone"});

$('#draggable').bind('dragstop', function(event, ui)
 {
    $(this).after($(ui.helper).clone().draggable());



});
    
   } );



//   $( function() {
//     $( "#draggable" ).draggable();
    
//   } );
//   </script>

  <script>
     $( function() {
  //$( "#draggable" ).draggable({ helper: "clone" });

  $('#1').draggable({helper: "clone"});


$('#1').bind('dragstop', function(event, ui)
 {
    $(this).after($(ui.helper).clone().draggable());



});
    
   } );



//   $( function() {
//     $( "#draggable" ).draggable();
    
//   } );
//   </script>

 <script>
     $( function() {
  $( "#d2" ).draggable({ helper: "clone" });

  $('#d2').draggable({helper: "clone"});

$('#d2').bind('dragstop', function(event, ui) {
    $(this).after($(ui.helper).clone().draggable());
});
    
   } );



//   $( function() {
//     $( "#draggable" ).draggable();
    
//   } );
//   </script>


//   <script>
//   $( function() {
//     $( "#d2" ).draggable();
//   } );
//   </script>

//   <script type="text/javascript">
//    $(function(){
//     var $button = $('.button').clone();
//   $('.package').html($button);
// });
  </script>


</head>
<body>

<div class="container">
  <div class ="row">

     <div class = "col-md-3">
   
  <div class="panel-group" id="accordion">
    <div class="panel panel-default">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a data-toggle="collapse" data-parent="#accordion" href="#collapse1">Collapsible Group 1</a>
        </h4>
      </div>
      <div id="collapse1" class="panel-collapse collapse in">
        <div class="panel-body">
          <svg width="100" height="100" id="draggable" >
  <circle cx="50" cy="50" r="40" stroke="green" stroke-width="4" fill="yellow" />
</svg>

<svg width="300" height="50" id="d2">
  <rect width="200" height="100" style="fill:rgb(0,0,255);stroke-width:10;stroke:rgb(0,0,0)" />
</svg>




        </div>
      </div>
    </div>
    <div class="panel panel-default">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a data-toggle="collapse" data-parent="#accordion" href="#collapse2">Flowchart Icons</a>
        </h4>
      </div>
      <div id="collapse2" class="panel-collapse collapse">
        
        <img src="<?php echo base_url() ?>flowicon/1.png" width="100" height="100" id="1">
          <img src="<?php echo base_url() ?>flowicon/1.png" width="100" height="100" id="2">

  <img src="<?php echo base_url() ?>flowicon/1.png" width="100" height="100" id="f1">

  <img src="<?php echo base_url() ?>flowicon/2.png" width="100" height="100" id="f2">

  <img src="<?php echo base_url() ?>flowicon/3.png" width="100" height="100" id="3">

  <img src="<?php echo base_url() ?>flowicon/4.png" width="100" height="100" id="4">

  <img src="<?php echo base_url() ?>flowicon/5.png" width="100" height="100" id="5">

  <img src="<?php echo base_url() ?>flowicon/6.png" width="100" height="100" id="6">

  <img src="<?php echo base_url() ?>flowicon/7.png" width="100" height="100" id="7">

    </div>
    <div class="panel panel-default">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a data-toggle="collapse" data-parent="#accordion" href="#collapse3">Collapsible Group 3</a>
        </h4>
      </div>
      <div id="collapse3" class="panel-collapse collapse">
        <div class="panel-body">Lorem ipsum dolor sit amet,  </div>
    </div>
  </div> 
  </div>

  <div class ="col-md-9" >

    

     </div>
  
</div>
    
</body>
</html>
