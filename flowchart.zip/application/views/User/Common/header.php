  <header class="header">
    <div class="container">
      <nav class="navbar navbar-expand-lg">
        <!-- Brand -->
        <a class="navbar-brand" href="#">FLOWCHART <span class="theme-bg"></span></a>
        <!-- / -->

        <!-- Mobile Toggle -->
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarshark" aria-controls="navbarshark" aria-expanded="false" aria-label="Toggle navigation">
            <span></span>
            <span></span>
            <span></span>
        </button>
        <!-- / -->

        <!-- Top Menu -->
        <div class="collapse navbar-collapse justify-content-end" id="navbarshark">
          <ul class="navbar-nav ml-auto">
            <li><a class="nav-link active" href="<?php echo base_url() ?>User">Home</a></li>
            <li><a class="nav-link" href="features.html">Features</a></li>
            <li><a class="nav-link" href="price.html">Price</a></li>
            <li><a class="nav-link" href="contact.html">Contact</a></li>
            <?php if(!empty($this->session->userdata('reg_name'))){
              ?>
               <li><a class="nav-link-btn" href="<?php echo base_url() ?>User/profile"  >Account</a></li>


            <?php  } ?>
           
            <li><a class="nav-link-btn" data-toggle="modal" data-target="#myModal"  >Registration</a></li>
           
            <?php if(!empty($this->session->userdata('reg_name'))){ ?>
            <li><a class="nav-link-btn" href="<?php echo base_url() ?>User/logout"  >logout</a></li>

              <?php  } 

              else { ?>
                   <li><a class="nav-link-btn" data-toggle="modal" data-target="#myModal2"  >Login</a></li>
          
                  
                <?php  }  ?>
            <p> <?php echo $this->session->userdata('reg_name'); ?> </p>
      
          </ul>
        </div>
        <!-- / -->
      </nav> <!-- Navbar -->     
    </div>
  </header>

    <!-- The Modal -->
  <div class="modal" id="myModal">
    <div class="modal-dialog">
      <div class="modal-content">
      
        <!-- Modal Header -->
        <div class="modal-header">
          <h4 class="modal-title">   <h4>Registration Here</h4></h4>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        
        <!-- Modal body -->
        <div class="modal-body">
          
            <div class="contact-form sm-m-30px-b">
           
              <form action="<?php echo base_url() ?>User/registration" method="POST">
                <div class="m-15px-b">
                  <input type="text" class="form-control" placeholder="Name" name="name" required="">
                </div>
                <div class="m-15px-b">
                  <input type="email" class="form-control" placeholder="Email" name="email" required="">
                </div>
                <div class="m-15px-b">
                  <input type="text" class="form-control" placeholder="Mobile" name="mobile" required="">
                </div>
                <div class="m-15px-b">
                    <input type="password" class="form-control" placeholder="Password" name="password" required="">
                </div>
                <input type="submit" class="m-btn btn-theme" name="submit" value="register">
               <!--  <button class="m-btn btn-theme">Register</button> -->
              </form>
            </div> <!-- contact fomr -->
         
        </div>
        
        <!-- Modal footer -->
       
        
      </div>
    </div>
  </div>


    <div class="modal" id="myModal2">
    <div class="modal-dialog">
      <div class="modal-content">
      
        <!-- Modal Header -->
        <div class="modal-header">
          <h4 class="modal-title">   <h4>Login Here</h4></h4>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        
        <!-- Modal body -->
        <div class="modal-body">
          
            <div class="contact-form sm-m-30px-b">
           
              <form action="<?php echo base_url() ?>User/login" method="POST">
               
                <div class="m-15px-b">
                  <input type="email" class="form-control" placeholder="Email" name="email" required="">
                </div>
                
                <div class="m-15px-b">
                    <input type="password" class="form-control" placeholder="Password" name="password" required="">
                </div>
                <input type="submit" class="m-btn btn-theme" name="submit" value="Login">
               <!--  <button class="m-btn btn-theme">Register</button> -->
              </form>
            </div> <!-- contact fomr -->
         
        </div>
        
        <!-- Modal footer -->
       
        
      </div>
    </div>
  </div>