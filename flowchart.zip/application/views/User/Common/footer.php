<footer class="footer">
    <div class="container">
      <div class="row">
        <div class="col-md-4 col-lg-5 sm-m-15px-tb">
          <h4>About Us</h4>
          <p class="footer-text">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
          tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
          quis nostrud exercitation</p>
          <ul class="social-icons">
            <li><a class="facebook" href="#"><i class="fab fa-facebook-f"></i></a></li>
            <li><a class="twitter" href="#"><i class="fab fa-twitter"></i></a></li>
            <li><a class="google" href="#"><i class="fab fa-google-plus-g"></i></a></li>
            <li><a class="linkedin" href="#"><i class="fab fa-linkedin-in"></i></a></li>
          </ul>
        </div> <!-- col -->

        <div class="col-md-5 col-lg-4 sm-m-15px-tb">
          <h4>Helpful Links</h4>
          <div class="d-flex justify-content-around">
            <ul class="list-style">
              <li><a href="#">Gym Training</a></li>
              <li><a href="#">Crossfit</a></li>
              <li><a href="#">Cardio</a></li>
              <li><a href="#">Contact</a></li>
              <li><a href="#">Blog</a></li>
            </ul>
            <ul class="list-style">
              <li><a href="#">About</a></li>
              <li><a href="#">Trainings</a></li>
              <li><a href="#">Coaches</a></li>
              <li><a href="<?php echo base_url() ?>Admin">Admin Login</a></li>
            </ul>
          </div>
        </div> <!-- col -->

        <div class="col-md-3 col-lg-3 sm-m-15px-tb">
          <h4 class="font-18 font-alt color-white font-w-600 m-0px m-15px-b">Get in touch</h4>
          <p>12345 Little Lonsdale St, Melbourne</p>
          <p><span>E-Mail:</span> info@example.com </p>
          <p><span>Phone:</span> (123) 123-456</p>
        </div> <!-- col -->

      </div>
      <div class="row">
        <div class="col-12 footer-copy">
          <p class="m-0px">All © Copyright by Flowchart. All Rights Reserved.</p>
        </div><!-- col -->
      </div> <!-- row -->
    </div> <!-- container -->   
  </footer>
 <script src="<?php echo base_url() ?>static/js/jquery-3.2.1.min.js"></script>
  <script src="<?php echo base_url() ?>static/js/jquery-migrate-3.0.0.min.js"></script>

  <!-- Plugins -->
  <script src="<?php echo base_url() ?>static/plugin/bootstrap/js/popper.min.js"></script>
  <script src="<?php echo base_url() ?>static/plugin/bootstrap/js/bootstrap.min.js"></script>
  <script src="<?php echo base_url() ?>static/plugin/owl-carousel/js/owl.carousel.min.js"></script>
  <script src="<?php echo base_url() ?>static/plugin/particles/particles.min.js"></script>
  <script src="<?php echo base_url() ?>static/plugin/particles/particles-app.js"></script>
  <!-- custom -->
  <script src="<?php echo base_url() ?>static/js/custom.js"></script>
