
     $( function() {
  $( "#f2" ).draggable({ helper: "clone" });

  $('#f2').draggable({helper: "clone"});

$('#f2').bind('dragstop', function(event, ui) {
    $(this).after($(ui.helper).clone().draggable());
});
    
   } );


