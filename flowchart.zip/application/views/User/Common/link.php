
  <!---Font Icon-->
  <link href="<?php echo base_url(); ?>static/plugin/font-awesome/css/fontawesome-all.min.css" rel="stylesheet">
  <link href="<?php echo base_url(); ?>static/plugin/et-line/style.css" rel="stylesheet">
  <link href="<?php echo base_url(); ?>static/plugin/themify-icons/themify-icons.css" rel="stylesheet">
  <!-- / -->

  <!-- Plugin CSS -->
  <link href="<?php echo base_url(); ?>static/plugin/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="<?php echo base_url(); ?>static/plugin/owl-carousel/css/owl.carousel.min.css" rel="stylesheet">
  <!-- / -->

  <!-- Theme Style -->
  <link href="<?php echo base_url(); ?>static/css/styles.css" rel="stylesheet">
  <link href="<?php echo base_url(); ?>static/css/color/default.css" rel="stylesheet" id="color_theme">
  <!-- / -->

  <!-- Favicon -->
  <link rel="icon" href="favicon.ico" />

   <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
  <!-- / -->