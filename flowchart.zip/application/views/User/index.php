<!DOCTYPE html>
<html lang="en">


<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  
  <title>Flowchart</title>
  <!-- / -->
<?php $this->load->view('User/Common/link'); ?>
</head>

<!-- Body Start -->
<body>

  <!-- Loading -->
  <div id="loading">
    <div class="load-circle"><span class="one"></span></div>
  </div>
  <!-- / -->

  <!-- Header -->
<?php $this->load->view('User/Common/header');  ?>
  <!-- Header End -->
  
  <!-- Main Start -->
  <main>

    <!-- Home Banner -->
    <section id="home" class="home-banner particles-box theme-g-bg">
      <div class="container">
        <div class="row justify-content-center">
          <div class="col-md-12 col-lg-10 text-center">
            <span>Best tool for</span>
            <h1>FLOWCHART<br/> & DIAGRAMS</h1>
            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam.</p>
            
          </div>
          <div class="col-md-8">
            <div class="hb-img">
              <img src="static/img/macbook.png" title="" alt="">
            </div>
          </div>
        </div>
      </div> <!-- container -->
    </section>
    <!-- / -->

    <!-- Features -->
    <section class="feature-section p-50px-t p-90px-b md-p-50px-tb">
      <div class="container">
        <div class="row">
          <div class="col-md-12 text-center m-40px-b sm-m-30px-b">
            <div class="section-title">
              <span class="theme-g-bg"></span>
              <h2>What is Software?</h2>
              <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis.</p>
            </div>
          </div> <!-- col -->
        </div> <!-- row -->

        <div class="row">
          <div class="col-md-4">
            <div class="feature-box sm-m-30px-b">
              <div class="f-icon theme-bg"><i class="icon-genius"></i></div>
              <h4 class="m-25px-t">Constant Speed</h4>
              <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis</p>
              <a class="more" href="#">Read More <i class="ti-arrow-right"></i></a>
            </div>
          </div>

          <div class="col-md-4">
            <div class="feature-box sm-m-30px-b">
              <div class="f-icon theme-bg"><i class="icon-documents"></i></div>
              <h4>File Management</h4>
              <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis</p>
              <a class="more" href="#">Read More <i class="ti-arrow-right"></i></a>
            </div>
          </div>

          <div class="col-md-4">
            <div class="feature-box sm-m-30px-b">
              <div class="f-icon theme-bg"><i class="icon-recycle"></i></div>
              <h4>Best Support</h4>
              <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis</p>
              <a class="more" href="#">Read More <i class="ti-arrow-right"></i></a>
            </div>
          </div>
        </div>
      </div> <!-- container -->
    </section>
    <!-- / -->

    <!-- sub section -->
    <section class="sub-section">
      <div class="container">
        <div class="row align-items-center m-60px-b">
          <div class="col-md-6">
            <img src="static/img/fow1.png" title="" alt="">
          </div> <!-- col -->
          <div class="col-md-6 sm-m-30px-t">
            <h6 class="sub-title theme-color">Landing Page </h6>
            <h4 class="sub-section-title m-0px m-15px-b">Creative Bootstrap 4 Landing <br/>Page Template</h4>
            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
            <ul class="ul-list-style m-20px-b">
              <li>Constant Speed</li>
              <li>File Management</li>
              <li>Best Support</li>
            </ul>
            <a class="m-btn btn-theme" href="#">Sign Up For Beta</a>
          </div> <!-- col -->
        </div> <!-- row -->

        <div class="row align-items-center m-60px-b">
          <div class="col-md-6 order-2 sm-m-30px-t order-md-first">
            <h6 class="sub-title theme-color">Landing Page </h6>
            <h4 class="sub-section-title m-0px m-15px-b">Creative Bootstrap 4 Landing <br/>Page Template</h4>
            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
            <ul class="ul-list-style m-20px-b">
              <li>Constant Speed</li>
              <li>File Management</li>
              <li>Best Support</li>
            </ul>
            <a class="m-btn btn-theme" href="#">Sign Up For Beta</a>
          </div> <!-- col -->
          <div class="col-md-6">
            <img src="static/img/flow2.png" title="" alt="">
          </div> <!-- col -->
        </div> <!-- row -->

        <div class="row align-items-center m-90px-b">
          <div class="col-md-6">
            <img src="static/img/flow3.png" title="" alt="">
          </div> <!-- col -->
          <div class="col-md-6 sm-m-30px-t">
            <h6 class="sub-title theme-color">Landing Page </h6>
            <h4 class="sub-section-title m-0px m-15px-b">Creative Bootstrap 4 Landing <br/>Page Template</h4>
            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
            <ul class="ul-list-style m-20px-b">
              <li>Constant Speed</li>
              <li>File Management</li>
              <li>Best Support</li>
            </ul>
            <a class="m-btn btn-theme" href="#">Sign Up For Beta</a>
          </div> <!-- col -->
        </div> <!-- row -->

      </div> <!-- container -->
    </section>
    <!-- / -->

    <!-- Testimonial -->
    <section class="p-60px-tb sm-p-40px-tb testimonial-section">
      
      <div class="container">
        <div class="row m-25px-b sm-m-15px-b">
          <div class="col-md-12 text-center">
            <div class="section-title white">
              <h2>What Client Say?</h2>
            </div>
          </div> <!-- col -->
        </div>

        <div class="row justify-content-center">
          <div class="col-md-10">
              <div id="client-slider-single" class="owl-carousel">
                <div class="testimonial-col">
                  <div class="d-flex">
                      <div class="img">
                        <span>
                          <img src="static/img/avtar1.jpg" alt="Shark" title="Shark" />
                        </span>
                      </div>
                      <div class="speac">
                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s.</p>
                        <h6><strong>Maria - <span class="theme-color">Owner</span></strong></h6>
                      </div>
                    </div>
                </div> <!-- col -->  

                <div class="testimonial-col">
                  <div class="d-flex">
                      <div class="img">
                        <span>
                          <img src="static/img/avtar1.jpg" alt="Shark" title="Shark" />
                        </span>
                      </div>
                      <div class="speac">
                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s.</p>
                        <h6><strong>Maria - <span class="theme-color">Owner</span></strong></h6>
                      </div>
                    </div>
                </div> <!-- col -->  

                <div class="testimonial-col">
                  <div class="d-flex">
                      <div class="img">
                        <span>
                          <img src="static/img/avtar1.jpg" alt="Shark" title="Shark" />
                        </span>
                      </div>
                      <div class="speac">
                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s.</p>
                        <h6><strong>Maria - <span class="theme-color">Owner</span></strong></h6>
                      </div>
                    </div>
                </div> <!-- col -->  

                <div class="testimonial-col">
                  <div class="d-flex">
                      <div class="img">
                        <span>
                          <img src="static/img/avtar1.jpg" alt="Shark" title="Shark" />
                        </span>
                      </div>
                      <div class="speac">
                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s.</p>
                        <h6><strong>Maria - <span class="theme-color">Owner</span></strong></h6>
                      </div>
                    </div>
                </div> <!-- col -->  

              </div> <!-- owl -->
          </div> <!-- col -->
        </div> <!-- row -->
      </div> <!-- container -->
    </section>
    <!--  Testimonial End  -->

    <!-- trusted clients -->
    <section class="trusted-clients p-60px-tb">
      <div class="container">
        <div class="row align-items-center">
          <div class="col-md-6">
            <div class="tc-left sm-m-30px-b">
              <span class="theme-color">Trusted</span>
              <h2>Our trusted<br/>Clients</h2>
              <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam</p>
              <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt.</p>
              <a class="m-btn btn-theme" href="#">Sign Up For Beta</a>
            </div>
          </div> <!-- col -->
          <div class="col-md-6">
            <div class="clients-list clients-border clients-col-3">
              <ul>
                <li>
                  <img src="static/img/logo-1.png" alt="" title="">
                </li>
                <li>
                  <img src="static/img/logo-2.png" alt="" title="">
                </li>
                <li>
                  <img src="static/img/logo-3.png" alt="" title="">
                </li>
                <li>
                  <img src="static/img/logo-4.png" alt="" title="">
                </li>
                <li>
                  <img src="static/img/logo-5.png" alt="" title="">
                </li>
                <li>
                  <img src="static/img/logo-6.png" alt="" title="">
                </li>
              </ul>
            </div>
          </div>

        </div> <!-- row -->
      </div> <!-- container -->
    </section>
    <!-- / -->

  </main>
  <!-- Main End -->

  <!-- Footer -->
  
  <!-- / -->

  <!-- jQuery -->
 <?php $this->load->view('User/Common/footer'); ?>
</body>
<!-- Body End -->


</html>