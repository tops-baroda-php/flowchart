<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
		function __construct()
	{
		parent::__construct();
		$this->load->Model('Model');
		
	}





	public function draw_diagram()
	{
		$this->load->view('User/diagram');
	}

	public function draw()
	{
		$this->load->view('User/draw');
	}
	public function index()
	{
		$this->load->view('User/index');
	}

	public function registration()
	{
		$data['reg_name'] = $this->input->post('name');
		$data['reg_email'] = $this->input->post('email');
		$data['reg_email'] = $this->input->post('mobile');
		$data['reg_password'] = $this->input->post('password');

		$sql = $this->Model->insert("registration",$data);

		if($sql)
		{
			redirect('User');
		}
		else
		{
			echo "Error
			";
		}
	}

	public  function login()
	{
       
			$data['reg_email'] = $this->input->post('email');
			$data['reg_password'] = $this->input->post('password');
	//print_r($data);

			$login = $this->Model->Select_where("registration",$data);
		
			if(count($login) == 1)
			{
				$sess_array = array();
				foreach ($login as $row) {
					$sess_array = array(

						"reg_id" => $row->reg_id,
						"reg_name" => $row->reg_name,
						"reg_email" => $row->reg_email,
						"reg_password" => $row->reg_password
						);

					$this->session->set_userdata($sess_array);
						//echo $this->session->userdata('reg_name');
					redirect('User/profile');


				}



			}
			else
			{
				echo "Error:please check email password";
			}

			
		

	}

	public function logout()
	{
		session_destroy();
		redirect('User');
	}

	public function profile()
	{
		if(empty($this->session->userdata('reg_name')))
		{
			redirect('User');
		}
		$this->load->view('User/profile');
	}

}
